package eu.kartoffelquadrat.bookstoreinternals;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestLauncher {
    public static void main(String[] args) {
        SpringApplication.run(RestLauncher.class, args);
    }
}
