package eu.kartoffelquadrat.bookstoreinternals;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class BookstoreService {	

	@Autowired
	private GlobalStockImpl mGlobalStockService;
	
	@Autowired
	private CommentsImpl mCommentService;
	
	@Autowired
	private AssortmentImpl mAssortmentService;
	
	public BookstoreService() {}
	
	@GetMapping("/bookstore/isbns")
	public Collection<Long> getListOfIsbns(){
		return mAssortmentService.getEntireAssortment();
	}
	
	@GetMapping("/bookstore/isbns/{isbn}")
	public BookDetailsImpl getBookByIsbn(@PathVariable("isbn") Long isbn){
		return mAssortmentService.getBookDetails(isbn);
	}
	
	@PutMapping("/bookstore/isbns/")
	public void createBook(@RequestBody BookDetailsImpl  book){
		mAssortmentService.addBookToAssortment(book);
	}
	
	@GetMapping("/bookstore/isbns/{isbn}/comments")
	public Map<Long, String> getCommentsOfBookByIsbn(@PathVariable("isbn") Long isbn){
		return mCommentService.getAllCommentsForBook(isbn);
	}
	
	@PostMapping("/bookstore/isbns/{isbn}/comments")
	public void addCommentForBookWithIsbn(@PathVariable("isbn") Long isbn,
			@RequestBody String comment){
		mCommentService.addComment(isbn, comment);
	}
	
	@DeleteMapping("/bookstore/isbns/{isbn}/comments")
	public void deleteCommentForBookWithIsbn(@PathVariable("isbn") Long isbn){
		mCommentService.removeAllCommentsForBook(isbn);
	}
	
	@PostMapping("/bookstore/isbns/{isbn}/comments/{commentId}")
	public void editCommentOfBookByIsbn(@PathVariable("isbn") Long isbn,
			@PathVariable("commentId") Long commentId,
			@RequestBody String updatedComment){
		mCommentService.editComment(isbn, commentId, updatedComment);		
	}
	
	@DeleteMapping("/bookstore/isbns/{isbn}/comments/{commentId}")
	public void deleteCommentOfBookByIsbn(@PathVariable("isbn") Long isbn,
			@PathVariable("commentId") Long commentId){
		mCommentService.deleteComment(isbn, commentId);		
	}	
	
	@GetMapping("/bookstore/stocklocations")
	public Collection<String> getStoreLocations(){
		return mGlobalStockService.getStoreLocations();
	}
	
	@GetMapping("/bookstore/stocklocations/{city}")
	public Map<Long, Integer> getStockForCity(@PathVariable("city") String city){
		return mGlobalStockService.getEntireStoreStock(city);
	}
	
	@GetMapping("/bookstore/stocklocations/{city}/{isbn}")
	public int getStockOfBookAtLocation(@PathVariable("isbn") Long isbn,
			@PathVariable("city") String city){
		return mGlobalStockService.getStock(city, isbn);
	}
	
	@PostMapping("/bookstore/stocklocations/{city}/{isbn}")
	public void getStockOfBookAtLocation(@PathVariable("isbn") Long isbn,
			@PathVariable("city") String city,
			@RequestBody Integer newAmount){
		mGlobalStockService.setStock(city, isbn, newAmount);				
	}
}
