package eu.anonymous4doubleblinded.xoxinternals.controller;

import eu.anonymous4doubleblinded.xoxinternals.model.BoardReadOnly;
import eu.anonymous4doubleblinded.xoxinternals.model.Player;
import eu.anonymous4doubleblinded.xoxinternals.model.XoxInitSettings;

import java.util.Collection;

public interface XoxManager {

    Collection<Long> getGames();

    void removeGame(long gameId);

    long addGame(XoxInitSettings initSettings);

    BoardReadOnly getBoard(long gameId);

    Player[] getPlayers(long gameId);

    XoxClaimFieldAction[] getActions(long gameId, String player);

    void performAction(long gameId, String player, int actionIndex);

    Ranking getRanking(long gameId);
}
